def get_data(filename: str) -> None:
    # your code goes here

def main():
    get_data('rawdata.txt')

main()