import string

def get_words(comment: str) -> list:
    """ Get a list of words (lowercased without punctuation) from a written
    comment

    Parameters:
        comment (str): A review 
    Returns:
        words (list): Lowercased and cleaned words in list

    For example, 
    get_words('A review without punctuation') must return 
    ['a', 'review', 'without', 'punctuation']

    get_words('This includes: punctuation.') must return
    ['this', 'includes', 'punctuation']
    """
    words = comment.strip().split()

    # Remove punctuation and convert to lowercase
    i = 0
    while i < len(words):
        cleaned = ''
        for ch in words[i]:
            if ch in string.ascii_letters or ch in string.digits:
                cleaned += ch.lower()
        if len(cleaned) == 0:
            del words[i]
        else:
            words[i] = cleaned
            i += 1

    return words

def analyze(model_filename: str, data_filename:str) -> list:
    results = []
    # read our model and get a dictionary

    # read data file with new comments
    # for each comment
    # get the words
    # for each word in the dictionary add to the total rating and to the count

    # add a new sublist in my results list with the average rating and the comment

    return results

def save2file(results :list) -> None:
    pass
def main() -> None:
    # analyze
    # save
    pass

main()
