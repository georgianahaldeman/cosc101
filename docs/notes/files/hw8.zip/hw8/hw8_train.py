import string

def get_words(comment: str) -> list:
    """ Get a list of words (lowercased without punctuation) from a written
    comment

    Parameters:
        comment (str): A review 
    Returns:
        words (list): Lowercased and cleaned words in list

    For example, 
    get_words('A review without punctuation') must return 
    ['a', 'review', 'without', 'punctuation']

    get_words('This includes: punctuation.') must return
    ['this', 'includes', 'punctuation']
    """
    words = comment.strip().split()

    # Remove punctuation and convert to lowercase
    i = 0
    while i < len(words):
        cleaned = ''
        for ch in words[i]:
            if ch in string.ascii_letters or ch in string.digits:
                cleaned += ch.lower()
        if len(cleaned) == 0:
            del words[i]
        else:
            words[i] = cleaned
            i += 1

    return words

def train(train_filename: str) -> dict:
    # use get_data - need to split the comment out from the score
    model = {}
    # model is going to store each word as key
    # with the values a data structure holding 2 values
    # one for the total rating
    # one for the counts of number of ratings


    # open train file and read line by line
    # separate out the score from the comment in the line
    # call get_data to get the list of words
    # update our model with the new rating for each word
    
    return model

def save_model(model_filename: str) -> None:
    pass

def main() -> None:
    print(train("hw8_small_train.txt"))

    #save_model()

main()
