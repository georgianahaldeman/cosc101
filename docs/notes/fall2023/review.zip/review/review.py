
def read_file(fname: str) -> dict:
    data = {}
    with open(fname) as finput:
        # read every record
        for line in finput:
            record_items = line.strip().split(' ')
            # print(record_items)
            data[record_items[0]] = []
            for item in record_items[1:]:
                data[record_items[0]].append(int(item))
    return data

def compute_stats(scores: list) -> list:
    lst = []
    lst.append(min(scores))
    lst.append(max(scores))
    lst.append(sum(scores)/len(scores))
    return lst

def write_stats(data: dict, fname: str) -> None:
    with open(fname, 'a') as fout:
        for name in data:
            stats = compute_stats(data[name])
            fout.write(f"{name} [{stats[0]},{stats[1]},{stats[2]}]\n")


def append_stats(fname: str) -> None:
    data = read_file(fname)
    print(data)
    write_stats(data, fname)

append_stats('scores.txt')