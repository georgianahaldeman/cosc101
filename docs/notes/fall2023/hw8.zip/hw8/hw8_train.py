import string
import pprint
def get_words(comment: str) -> list:
    """ Get a list of words (lowercased without punctuation) from a written
    comment

    Parameters:
        comment (str): A review 
    Returns:
        words (list): Lowercased and cleaned words in list

    For example, 
    get_words('A review without punctuation') must return 
    ['a', 'review', 'without', 'punctuation']

    get_words('This includes: punctuation.') must return
    ['this', 'includes', 'punctuation']
    """
    words = comment.strip().split()

    # Remove punctuation and convert to lowercase
    i = 0
    while i < len(words):
        cleaned = ''
        for ch in words[i]:
            if ch in string.ascii_letters or ch in string.digits:
                cleaned += ch.lower()
        if len(cleaned) == 0:
            del words[i]
        else:
            words[i] = cleaned
            i += 1

    return words

def update_model(dmodel:dict, line: str) -> None:
    # split words
    # extract the first "word" and convert to a float 
    # go through every word left and for each do as follows
    # if not in the dictionary then add it with the rating and 1
    # if it's in the dicitonary then add the rating to the first element in
    # the list and then add 1 to the second element in the list
    pass

def train(filename: str) -> dict:
    dsntmt = {}
    # open the file
    # go line by line
    # call update_model with the new line


    return dsntmt

def save_model(model: dict) -> None:
    pass

def main() -> None:
    model = train("hw8_test_train_single.txt")
    pprint.pprint(model)

    # ?? compute averages before writing to the file???

    #save the model to a file 
    save_model(model)

main()
