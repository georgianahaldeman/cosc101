import string

def get_words(comment: str) -> list:
    """ Get a list of words (lowercased without punctuation) from a written
    comment

    Parameters:
        comment (str): A review 
    Returns:
        words (list): Lowercased and cleaned words in list

    For example, 
    get_words('A review without punctuation') must return 
    ['a', 'review', 'without', 'punctuation']

    get_words('This includes: punctuation.') must return
    ['this', 'includes', 'punctuation']
    """
    words = comment.strip().split()

    # Remove punctuation and convert to lowercase
    i = 0
    while i < len(words):
        cleaned = ''
        for ch in words[i]:
            if ch in string.ascii_letters or ch in string.digits:
                cleaned += ch.lower()
        if len(cleaned) == 0:
            del words[i]
        else:
            words[i] = cleaned
            i += 1

    return words

def input_model(fmodel: str) -> dict:
    # open model file and produce the model dictionary
    pass

def analyze_line(dmodel:dict, line: str) -> list:
    # separate the words in the line
    # for each word in the line 
    # take its rating from the dicitonary and add to a sum of ratings
    # increase the counts by 1
    pass

def analyze(fmodel: str, fanalyze: str) -> list:
    rlst = []
    # call input model to get the dicitonary model
    # open the analyze file
    # read line by line
    # call analyze_line and append it to the list
    return rlst

def save_analyze(results: list) -> None:
    pass

def main() -> None:
    results = analyze("hw8_small_model.txt","hw8_test_analyze_single.txt")

    # save generated list with ratings to a file
    save_analyze(results)

main()
